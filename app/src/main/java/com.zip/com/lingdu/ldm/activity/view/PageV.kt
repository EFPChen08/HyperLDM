/*
 * BlockMIUI
 * Copyright (C) 2022 fkj@fkj233.cn
 * https://github.com/577fkj/BlockMIUI
 *
 * This software is free opensource software: you can redistribute it
 * and/or modify it under the terms of the GNU Lesser General Public License v2.1
 * as published by the Free Software Foundation; either
 * version 3 of the License, or any later version and our eula as published
 * by 577fkj.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * GNU Lesser General Public License v2.1 for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License v2.1
 * and eula along with this software.  If not, see
 * <https://www.gnu.org/licenses/>
 * <https://github.com/577fkj/BlockMIUI/blob/main/LICENSE>.
 */

package com.lingdu.ldm.activity.view

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.lingdu.ldm.R
import com.lingdu.ldm.activity.data.DataBinding
import com.lingdu.ldm.activity.data.LayoutPair
import com.lingdu.ldm.activity.dp2px
import com.lingdu.ldm.activity.fragment.MIUIFragment
import com.lingdu.ldm.activity.isRtl

class PageV(
    private val pageHead: Drawable,
    private val pageName: String?,
    private val pageNameId: Int?,
    private val round: Float = 0f,
    private val onClick: (() -> Unit)? = null,
    private val dataBindingRecv: DataBinding.Binding.Recv? = null
) : BaseView {

    override fun getType(): BaseView {
        return this
    }

    override fun create(context: Context, callBacks: (() -> Unit)?): View {
        return LinearContainerV(LinearContainerV.HORIZONTAL, arrayOf(
            LayoutPair(
                RoundCornerImageView(context, dp2px(context, round), dp2px(context, round)).also {
                    it.background = pageHead
                },
                LinearLayout.LayoutParams(
                    dp2px(context, 30f),
                    dp2px(context, 30f)
                )
            ),
            LayoutPair(
                TextView(context).also {
                    if (isRtl(context))
                        it.setPadding(0, 0, dp2px(context, 16f), 0)
                    else
                        it.setPadding(dp2px(context, 16f), 0, 0, 0)
                    it.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                    it.setTextColor(context.getColor(R.color.whiteText))
                    pageName?.let { it1 -> it.text = it1 }
                    pageNameId?.let { it1 -> it.setText(it1) }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        it.paint.typeface = Typeface.create(null, 500, false)
                    } else {
                        it.paint.typeface = Typeface.defaultFromStyle(Typeface.BOLD)
                    }
                },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { it.gravity = Gravity.CENTER_VERTICAL }
            ),
            LayoutPair(
                ImageView(context).also { it.background = context.getDrawable(R.drawable.ic_right_arrow) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.CENTER_VERTICAL })
        ), layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).also {
            it.setMargins(0, dp2px(context, 14.8f), 0, dp2px(context, 14.8f))
        }).create(context, callBacks).also {
            dataBindingRecv?.setView(it)
        }
    }

    override fun onDraw(thiz: MIUIFragment, group: LinearLayout, view: View) {
        thiz.apply {
            group.apply {
                addView(view)
                onClick?.let { unit ->
                    setOnClickListener {
                        unit()
                        callBacks?.let { it1 -> it1() }
                    }
                }
            }
        }
    }
}