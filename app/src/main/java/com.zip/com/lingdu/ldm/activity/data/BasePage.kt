@file:Suppress("FunctionName")

package com.lingdu.ldm.activity.data

import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.TextView
import com.lingdu.ldm.activity.MIUIActivity
import com.lingdu.ldm.activity.fragment.MIUIFragment
import com.lingdu.ldm.activity.view.*

abstract class BasePage {
    val itemList: ArrayList<BaseView> = arrayListOf()
    var bindingData = arrayListOf<DataBinding.BindingData>()
    var skipLoadItem: Boolean = false
    lateinit var activity: MIUIActivity

    abstract fun onCreate()

    // ✅ 新增：获取页面大标题的方法，默认为空，子类重写
    open fun getPageTitle(): String = ""

    open fun asyncInit(fragment: MIUIFragment) {
        // 当页面初始化时，刷新 Activity 上的大标题
        activity.setPageTitle(getPageTitle())
    }

    fun showPage(page: Class<out BasePage>) {
        activity.showFragment(page.simpleName)
    }

    fun setTitle(title: String) {
        activity.title = title
        // 同时也更新大标题
        activity.setPageTitle(title)
    }

    open fun getTitle(): String = ""

    fun getString(id: Int): String = activity.getString(id)
    fun getDrawable(id: Int): Drawable = activity.getDrawable(id)!!
    fun getColor(id: Int): Int = activity.getColor(id)

    fun GetDataBinding(defValue: () -> Any, recvCallbacks: (View, Int, Any) -> Unit): DataBinding.BindingData {
        return DataBinding.get(bindingData, defValue, recvCallbacks)
    }

    fun ImageWithText(head: Drawable, name: String, tips: String? = null, round: Float = 30f, onClickListener: (() -> Unit)? = null, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(ImageTextV(head, name, tips, round, onClickListener, dataBindingRecv))
    }

    fun Page(pageHead: Drawable, pageName: String? = null, pageNameId: Int? = null, round: Float = 0f, onClickListener: (() -> Unit)? = null, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(PageV(pageHead, pageName, pageNameId, round, onClickListener, dataBindingRecv))
    }

    fun Line(dataBindingRecv: DataBinding.Binding.Recv? = null,) {
        itemList.add(LineV(dataBindingRecv))
    }

    fun SeekBarSwitchStyle(
        key: String,
        min: Int,
        max: Int,
        defaultProgress: Int,
        onChange: ((Int) -> Unit)? = null
    ) {
        itemList.add(MIUISeekBarV(key, min, max, defaultProgress, onChange = onChange))
    }

    fun SeekBar(key: String, min: Int, max: Int, defaultProgress: Int, dataSend: DataBinding.Binding.Send? = null, dataBindingRecv: DataBinding.Binding.Recv? = null, callBacks: ((Int, TextView) -> Unit)? = null) {
        itemList.add(SeekBarV(key, min, max, defaultProgress, dataSend, dataBindingRecv, callBacks))
    }

    fun SeekBarWithText(key: String = "", min: Int, max: Int, defaultProgress: Int = 0, dataBindingRecv: DataBinding.Binding.Recv? = null, dataBindingSend: DataBinding.Binding.Send? = null, callBacks: ((Int, TextView) -> Unit)? = null) {
        itemList.add(SeekBarWithTextV(key, min, max, defaultProgress, dataBindingRecv, dataBindingSend, callBacks))
    }

    fun Text(text: String? = null, textId: Int? = null, textSize: Float? = null, colorInt: Int? = null, colorId: Int? = null, padding: Padding? = null, dataBindingRecv: DataBinding.Binding.Recv? = null, typeface: Typeface? = null, onClickListener: (() -> Unit)? = null) {
        itemList.add(TextV(text, textId, textSize, colorInt, colorId, padding, dataBindingRecv, typeface, onClickListener))
    }

    fun TextWithSwitch(textV: TextV, switchV: SwitchV, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextWithSwitchV(textV, switchV, dataBindingRecv))
    }

    fun TextSw(text: String? = null, textId: Int? = null, key: String, defValue: Boolean = false, onClickListener: ((Boolean) -> Unit)? = null, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextWithSwitchV(TextV(text, textId), SwitchV(key, defValue, onClickListener = onClickListener), dataBindingRecv))
    }

    fun TextWithSpinner(textV: TextV, spinnerV: SpinnerV, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextWithSpinnerV(textV, spinnerV, dataBindingRecv))
    }

    fun TextSp(text: String? = null, textId: Int? = null, currentValue: String, data: SpinnerV.SpinnerData.() -> Unit, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextWithSpinnerV(TextV(text, textId), SpinnerV(currentValue, data = data), dataBindingRecv))
    }

    fun TextWithArrow(textV: TextV, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextWithArrowV(textV, dataBindingRecv))
    }

    fun TextA(text: String? = null, textId: Int? = null, onClickListener: (() -> Unit)? = null, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextWithArrowV(TextV(text, textId, onClickListener = onClickListener), dataBindingRecv))
    }

    fun TextWithSeekBar(textV: TextV, seekBarWithTextV: SeekBarWithTextV, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextWithSeekBarV(textV, seekBarWithTextV, dataBindingRecv))
    }

    fun TextSummary(text: String? = null, textId: Int? = null, tips: String? = null, colorInt: Int? = null, colorId: Int? = null, tipsId: Int? = null, dataBindingRecv: DataBinding.Binding.Recv? = null, onClickListener: (() -> Unit)? = null) {
        itemList.add(TextSummaryV(text, textId, tips, colorInt, colorId, tipsId, dataBindingRecv, onClickListener))
    }

    fun TextS(text: String? = null, textId: Int? = null, tips: String? = null, colorInt: Int? = null, colorId: Int? = null, tipsId: Int? = null, dataBindingRecv: DataBinding.Binding.Recv? = null, onClickListener: (() -> Unit)? = null) {
        itemList.add(TextSummaryV(text, textId, tips, colorInt, colorId, tipsId, dataBindingRecv, onClickListener))
    }

    fun TextSummaryWithSwitch(textSummaryV: TextSummaryV, switchV: SwitchV, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextSummaryWithSwitchV(textSummaryV, switchV, dataBindingRecv))
    }

    fun TextSSw(text: String? = null, textId: Int? = null, tips: String? = null, tipsId: Int? = null, key: String, defValue: Boolean = false, onClickListener: ((Boolean) -> Unit)? = null, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextSummaryWithSwitchV(TextSummaryV(text, textId, tips, tipsId = tipsId), SwitchV(key, defValue, onClickListener = onClickListener), dataBindingRecv))
    }

    fun TextSummaryWithSpinner(textSummaryV: TextSummaryV, spinnerV: SpinnerV, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextSummaryWithSpinnerV(textSummaryV, spinnerV, dataBindingRecv))
    }

    fun Card(
        onClick: (() -> Unit)? = null,
        block: CardScope.() -> Unit
    ) {
        val scope = CardScope()
        scope.block()
        if (scope.items.isNotEmpty()) {
            itemList.add(CardContainerV(scope.items, onClick))
        }
    }

    fun WhiteCard(block: CardScope.() -> Unit) {
        val scope = CardScope()
        scope.block()
        if (scope.items.isNotEmpty()) {
            itemList.add(WhiteCardContainerV(scope.items))
        }
    }

    fun TextSSp(text: String? = null, textId: Int? = null, tips: String? = null, tipsId: Int? = null, currentValue: String, data: SpinnerV.SpinnerData.() -> Unit, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextSummaryWithSpinnerV(TextSummaryV(text, textId, tips, tipsId), SpinnerV(currentValue, data = data), dataBindingRecv))
    }

    fun TextSummaryWithArrow(textSummaryV: TextSummaryV, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextSummaryWithArrowV(textSummaryV, dataBindingRecv))
    }

    fun TextSA(text: String? = null, textId: Int? = null, tips: String? = null, tipsId: Int? = null, onClickListener: (() -> Unit)? = null, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextSummaryWithArrowV(TextSummaryV(text = text, textId = textId, tips = tips, tipsId = tipsId, onClickListener = onClickListener), dataBindingRecv))
    }

    fun TextSummaryWithSeekBar(textSummaryV: TextSummaryV, seekBarWithTextV: SeekBarWithTextV, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(TextSummaryWithSeekBarV(textSummaryV, seekBarWithTextV, dataBindingRecv))
    }

    fun TitleText(text: String? = null, textId: Int? = null, colorInt: Int? = null, colorId: Int? = null, dataBindingRecv: DataBinding.Binding.Recv? = null, onClickListener: (() -> Unit)? = null) {
        itemList.add(TitleTextV(text, textId, colorInt, colorId, dataBindingRecv, onClickListener))
    }

    fun CustomView(view: View, dataBindingRecv: DataBinding.Binding.Recv? = null) {
        itemList.add(CustomViewV(view, dataBindingRecv))
    }

    fun RadioView(key: String, dataBindingRecv: DataBinding.Binding.Recv? = null, data: RadioViewV.RadioData.() -> Unit) {
        itemList.add(RadioViewV(key, dataBindingRecv, data))
    }
}