package com.lingdu.ldm.activity.annotation

import androidx.annotation.Keep

@Keep
annotation class BMPage(
    val hideMenu: Boolean = true
)
