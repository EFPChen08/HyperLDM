package com.lingdu.ldm

import android.content.Intent
import android.graphics.Typeface
import android.view.View
import android.widget.Switch
import androidx.compose.ui.window.DialogWindowProvider
import com.lingdu.ldm.MainActivity.Companion.showToast
import com.lingdu.ldm.R
import com.lingdu.ldm.activity.MIUIActivity
import com.lingdu.ldm.activity.annotation.BMMainPage
import com.lingdu.ldm.activity.data.BasePage
import com.lingdu.ldm.activity.data.Padding
import com.lingdu.ldm.activity.view.SpinnerV
import com.lingdu.ldm.activity.view.SwitchV
import com.lingdu.ldm.activity.view.TextSummaryV
import com.lingdu.ldm.activity.view.*
import com.lingdu.ldm.dialog.MIUIDialog
import com.lingdu.ldm.dialog.NewDialog
import com.lingdu.ldm.activity.view.TextSummaryWithArrowV
import com.lingdu.ldm.activity.fragment.MIUIFragment
import com.lingdu.ldm.activity.view.MIUIEditText
import com.lingdu.ldm.activity.view.TitleTextV
import com.lingdu.ldm.activity.view.BaseView
import com.lingdu.ldm.activity.view.BlockMiUIButton
import android.widget.LinearLayout
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat.startActivity
import com.lingdu.ldm.activity.annotation.BMPage
import com.lingdu.ldm.activity.dp2px
import com.lingdu.ldm.activity.data.CardScope

@BMPage
class TestPage : BasePage() {
    override fun getPageTitle(): String = "HyperLDM111"

    override fun onCreate() {

        setTitle("HyperLDM111")

        Card(onClick = {
            MIUIDialog(activity) {
                setTitle("设置")
                setMessage("你确定要设置吗？")
                setLButton("取消") {
                    dismiss()
                }
                setRButton("确定") {
                    // 这里的 'activity' 是 BasePage 类自带的变量，直接用！
                    val intent = Intent(activity, SetActivity::class.java)
                    activity.startActivity(intent)
                    dismiss()
                }
            }.show()
        }) {
            add(TextV("内容"))
        }
    }
}